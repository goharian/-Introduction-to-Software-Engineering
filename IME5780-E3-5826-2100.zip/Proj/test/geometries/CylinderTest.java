package geometries;

/**
 * @author BS"D Matanya Goharian, Yaniv Moradov <matanya.goharian@gmail.com >
 */
public class CylinderTest {

    /**
     * Test of getNormal method, of class Cylinder.
     */
    @org.junit.Test
    public void testGetNormal() {

    }
}
