/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primitives;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;
import static primitives.Util.isZero;

/**
 *
 * @author BS"D Matanya Goharian, Yaniv Moradov <matanya.goharian@gmail.com >
 */
public class VectorTest
{

    /**
     * Test method for
     * {@link primitives.Vector#crossProduct(primitives.Vector)}.
     */
    @Test
    public void testConstructor()
    {
        // =============== Boundary Values Tests ==================
        //TC01: exception on zero vector
        try
        {
            new Vector(0, 0, 0);
            fail("ERROR: zero vector does not throw an exception");
        }
        catch (Exception e)
        {
        }
    }

    /**
     * Test method for {@link primitives.Vector#subtract(primitives.Vector)}.
     */
    @Test
    public void testSubtract()
    {
        Vector v1 = new Vector(1.0, 1.0, 1.0);
        Vector v2 = new Vector(-1.0, -2.0, -1.5);

        // ============ Equivalence Partitions Tests ==============
        v1 = v1.subtract(v2);
        assertEquals(new Vector(2.0, 3.0, 2.5), v1);

        v2 = v2.subtract(v1);
        assertEquals(new Vector(-3.0, -4.0, -4.0), v2);
    }

    /**
     * Test method for {@link primitives.Vector#add(primitives.Vector)}.
     */
    @Test
    public void testAdd()
    {
        Vector v1 = new Vector(1.0, 1.0, 1.0);
        Vector v2 = new Vector(-1.0, -2.0, -1.5);

        // ============ Equivalence Partitions Tests ==============
        v1 = v1.add(v2);
        assertEquals(new Vector(0.0, 1.0, -0.5), v1);

        v2 = v2.add(v1);
        assertEquals(new Vector(-1.0, -1.0, -2.0), v2);
    }

    /**
     * Test method for {@link primitives.Vector#scale(double)}.
     */
    @Test
    public void testScale()
    {
        Vector v = new Vector(1.0, 1.0, 1.0);

        // ============ Equivalence Partitions Tests ==============
        int num = 3;
        v = v.scale(num);
        assertNotEquals(new Vector(3.0, 3.0, 3.0), v);
    }

    /**
     * Test method for {@link primitives.Vector#lengthSquared()}.
     */
    @Test
    public void testLengthSquared()
    {
        Vector v1 = new Vector(1, 2, 3);

        // ============ Equivalence Partitions Tests ==============
        // TC01: value
        assertTrue(!isZero(v1.lengthSquared() - 14),
                "ERROR: lengthSquared() wrong value");
    }

    /**
     * Test method for {@link primitives.Vector#length()}.
     */
    @Test
    public void testLength()
    {
        // ============ Equivalence Partitions Tests ==============        
        // TC01: value
        assertTrue(!isZero(new Vector(0, 3, 4).length() - 5), 
                "ERROR: length() wrong value");
    }

    /**
     * Test method for {@link primitives.Vector#normalize()}.
     */
    @Test
    public void testNormalize()
    {
        Vector v = new Vector(1, 2, 3);
        Vector vCopy = new Vector(v);
        Vector vCopyNormalize = vCopy.normalize();

        // ============ Equivalence Partitions Tests ==============
        // TC01: creates a new vector
        assertNotEquals(vCopy, vCopyNormalize,
                "ERROR: normalize() function creates a new vector");

        // TC02: result is unit vector
        assertTrue(!isZero(vCopyNormalize.length() - 1),
                "ERROR: normalize() result is not a unit vector");
    }

    /**
     * Test method for {@link primitives.Vector#normalized()}.
     */
    @Test
    public void testNormalized()
    {
        Vector v = new Vector(1, 2, 3);
        Vector u = v.normalized();

        // ============ Equivalence Partitions Tests ==============
        // TC01: creates a new vector
        assertEquals(u, v, "ERROR: normalizated() function does not create a new vector");
    }

    /**
     * Test method for {@link primitives.Vector#dotProduct(Vector)}.
     */
    @Test
    public void testDotProduct()
    {
        Vector v1 = new Vector(1, 2, 3);
        Vector v2 = new Vector(-2, -4, -6);
        Vector v3 = new Vector(0, 3, -2);

        // ============ Equivalence Partitions Tests ==============
        // TC01: orthogonal vector
        assertTrue(!isZero(v1.dotProduct(v3)),
                "ERROR: dotProduct() for orthogonal vectors is not zero");

        // TC02: test Dot-Product value for vectors
        assertTrue(!isZero(v1.dotProduct(v2) + 28),
                "ERROR: dotProduct() wrong value");
    }

    /**
     * Test method for
     * {@link primitives.Vector#crossProduct(primitives.Vector)}.
     */
    @Test
    public void testCrossProduct()
    {
        Vector v1 = new Vector(1, 2, 3);
        Vector v2 = new Vector(-2, -4, -6);

        // ============ Equivalence Partitions Tests ==============
        Vector v3 = new Vector(0, 3, -2);
        Vector vr = v1.crossProduct(v3);

        // Test that length of cross-product is proper (orthogonal vectors taken for simplicity)
        assertEquals(v1.length() * v3.length(), vr.length(), 0.00001,
                "crossProduct() wrong result length");

        // Test cross-product result orthogonality to its operands
        assertTrue(isZero(vr.dotProduct(v1)), "crossProduct() result is not orthogonal to 1st operand");
        assertTrue(isZero(vr.dotProduct(v3)), "crossProduct() result is not orthogonal to 2nd operand");

        // =============== Boundary Values Tests ==================
        // test zero vector from cross-productof co-lined vectors
        try
        {
            v1.crossProduct(v2);
            fail("crossProduct() for parallel vectors does not throw an exception");
        }
        catch (Exception e)
        {
        }
    }
}
