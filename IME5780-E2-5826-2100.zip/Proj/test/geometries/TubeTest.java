/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometries;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

/**
 *
 * @author BS"D Matanya Goharian, Yaniv Moradov <matanya.goharian@gmail.com >
 */
public class TubeTest
{
    /**
     * Test method for {@link geometries.Tube#getNormal(primitives.Point3D)}.
     */
    @Test
    public void testGetNormal()
    {
        Ray r = new Ray(new Vector(0,1,0), new Point3D(1,0,0));
        Tube t = new Tube(r, 1);
        
        // ============ Equivalence Partitions Tests ==============
        //TC01: result
        assertEquals(new Vector(-1, 0, 0), t.getNormal(new Point3D(2, 0, 0)), "getNormal() result is wrong");
    }    
}
