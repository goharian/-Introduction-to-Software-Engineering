/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometries;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import primitives.Point3D;
import primitives.Vector;

/**
 *
 * @author BS"D Matanya Goharian, Yaniv Moradov <matanya.goharian@gmail.com >
 */
public class TriangleTest
{
    /**
     * Test method for
     * {@link.geometries.Triangle#getNormal(geometries.Triangle)}.
     */
    @Test
    public void testGetNormal()
    {
        // ============ Equivalence Partitions Tests ==============
        //TC01: There is a simple single test here

        Triangle triangle = new Triangle(new Point3D(0, 0, 1), new Point3D(1, 0, 0), new Point3D(0, 1, 0));
        double sqrt3 = Math.sqrt(1d / 3);

        assertEquals(new Vector(sqrt3, sqrt3, sqrt3), triangle.getNormal(new Point3D(0, 0, 1)),
                "Bad normal to triangle");
    }

}
