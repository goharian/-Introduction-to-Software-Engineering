/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometries;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

/**
 *
 * @author BS"D Matanya Goharian, Yaniv Moradov <matanya.goharian@gmail.com >
 */
public class CylinderTest
{

    /**
     * Test of getNormal method, of class Cylinder.
     */
    @Test
    public void testGetNormal()
    {
        // ============ Equivalence Partitions Tests ==============
        Ray r = new Ray(new Vector(0, 1, 0), new Point3D(1, 0, 0));
        Cylinder c = new Cylinder(1, r, 5);
        
        assertEquals(new Vector(-1, 0, 0), c.getNormal(new Point3D(2, 1, 0)), 
                "getNormal() result is wrong");
        assertEquals(new Vector(0, -1, 0), c.getNormal(new Point3D(1.5, 0, 0)), 
                "getNormal() result is wrong");
        assertEquals(new Vector(0, 1, 0), c.getNormal(new Point3D(1.5, 5, 0)), 
                "getNormal() result is wrong");

        // ============ Boundary Tests ==============
        assertEquals(new Vector(0, -1, 0), c.getNormal(new Point3D(2, 0, 0)), 
                "getNormal() result is wrong");
        assertEquals(new Vector(0, 1, 0), c.getNormal(new Point3D(2, 5, 0)), 
                "getNormal() result is wrong");
    }
}
